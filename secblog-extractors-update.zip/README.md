# SecBlog — Cybersecurity & Malware Analysis Blog

A dark-themed static blog for publishing malware analysis reports, threat intelligence, and IOC feeds. Runs entirely on GitHub Pages — no backend, no CMS, no database.
<img width="2547" height="1282" alt="image" src="https://github.com/user-attachments/assets/3f342f70-d28c-4e01-b547-886780135078" />

## Quick Start

1. Fork or clone this repo
2. Edit `assets/js/config.js` with your name, bio, and links
3. Push to GitHub and enable GitHub Pages (Settings → Pages → main branch)

## Adding Reports

See [HOW-TO-ADD-REPORT.md](HOW-TO-ADD-REPORT.md) for the full guide.

Short version:
```bash
cp reports/report-template.html reports/my-new-report.html
# edit the HTML
# add entry to assets/js/reports-data.js
git add . && git commit -m "Add report" && git push
```

## Structure

```
secblog/
├── index.html              Homepage
├── reports.html            All reports + filter
├── ioc-feed.html           Aggregated IOC table + CSV export (reports + extractors)
├── extractors.html         YARA + extractor + extracted IOCs/config, add form
├── about.html              Author page
├── reports/
│   ├── report-template.html  Copy this for each new report
│   └── *.html               Your actual reports
├── assets/
│   ├── css/
│   │   ├── style.css        Global styles
│   │   └── report.css       Report page styles
│   └── js/
│       ├── config.js        ← EDIT THIS — your name/bio/links
│       ├── reports-data.js  ← EDIT THIS — one entry per report
│       ├── extractors-data.js ← one entry per extractor (export from extractors.html)
│       └── *.js             Page logic
├── HOW-TO-ADD-REPORT.md    Step-by-step guide
└── HOW-TO-ADD-EXTRACTOR.md Step-by-step guide for extractors
```

## License

Content © SalahEldin Kamil. Code: MIT.
